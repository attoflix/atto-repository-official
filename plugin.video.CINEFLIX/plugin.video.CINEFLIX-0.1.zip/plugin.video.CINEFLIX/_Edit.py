import xbmcaddon

MainBase = 'https://pastebin.com/raw/kUsDk9Jc'
addon = xbmcaddon.Addon('plugin.video.CINEFLIX')