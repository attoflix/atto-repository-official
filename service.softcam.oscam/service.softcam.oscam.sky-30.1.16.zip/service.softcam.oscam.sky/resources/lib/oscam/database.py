#!/usr/bin/env python
# -*- coding: utf-8 -*- 

import os
import xbmc
import xbmcgui
import xbmcaddon
import sqlite3

_Addon_ = xbmcaddon.Addon()
_AddonPath_ = xbmc.translatePath(_Addon_.getAddonInfo("path"))
_UserData_ = xbmc.translatePath(_Addon_.getAddonInfo("profile"))

class BD():
    def __init__(self):
        self.ServidorKS = False
        self.Settings = sqlite3.connect(os.path.join(os.path.join(_UserData_, "database"), "Settings.db"))

    def ObterSetting(self, Setting, RetornoPadrao):
        cursor = self.Settings.cursor()
        cursor.execute("SELECT Value FROM Settings WHERE Name = ? LIMIT 1", (Setting,))
        retorno = cursor.fetchall()
        if not len(retorno) > 0:
            return RetornoPadrao
        else:
            return retorno[0][0]

    def ObterListReaders(self):
        cursor = self.Settings.cursor()
        cursor.execute("SELECT rowid, URL, Porta, Usuario, Senha, DESKey, Status FROM Readers")
        readers = cursor.fetchall()

        retorno = []
        for rowid, URL, Porta, Usuario, Senha, DESKey, Status in readers:
            if len(Usuario) > 16:
                self.ServidorKS = True
            li = xbmcgui.ListItem("Servidor {0} (URL: {1} Usuário: {2})".format(rowid, URL, Usuario if len(Usuario) < 16 else "KS válido até: {0}".format(_Addon_.getSetting(id="KSValidATE"))), Status, os.path.join(_AddonPath_, "resources", "images", "Checked.png") if Status == "checked" else os.path.join(_AddonPath_, "resources", "images", "Unchecked.png"))
            li.setProperty("Path", "?rowid=>{0}&URL=>{1}&Porta=>{2}&Usuario=>{3}&Senha=>{4}&DESKey=>{5}".format(rowid, URL, Porta, Usuario, Senha, DESKey))
            retorno.append(li)

        return retorno

    def ObterArrayReaders(self):
        cursor = self.Settings.cursor()
        cursor.execute("SELECT rowid, URL, Porta, Usuario, Senha, DESKey, Status FROM Readers")
        readers = cursor.fetchall()
        self.Settings.close();
        return readers

    def AtualizarSetting(self, Setting, Valor):
        cursor = self.Settings.cursor()

        if self.ObterSetting(Setting, None) == None:
            cursor.execute("INSERT INTO Settings (Name, Value) VALUES (?, ?)", (Setting, Valor))
        else:
            cursor.execute("UPDATE Settings SET Value = ? WHERE Name = ?", (Valor, Setting))
        self.Settings.commit()

    def AtualizarReader(self, RowID, URL, Porta, Usuario, Senha, DESKey):
        cursor = self.Settings.cursor()
        cursor.execute("UPDATE Readers SET URL = ?, Porta = ?, Usuario = ?, Senha = ?, DESKey = ? WHERE rowid = ?", (URL, Porta, Usuario, Senha, DESKey, RowID))
        self.Settings.commit()

    def InserirReader(self, URL, Porta, Usuario, Senha, DESKey, Status="checked"):
        cursor = self.Settings.cursor()
        cursor.execute("INSERT INTO Readers (URL, Porta, Usuario, Senha, DESKey, Status) VALUES (?, ?, ?, ?, ?, ?)", (URL, Porta, Usuario, Senha, DESKey, Status))
        self.Settings.commit()
        return cursor.execute("SELECT rowid FROM Readers ORDER BY rowid DESC LIMIT 1").fetchall()[0][0]

    def ExcluirReader(self, RowID):
        cursor = self.Settings.cursor()
        cursor.execute("DELETE FROM Readers WHERE rowid = ?", (RowID,))
        self.Settings.commit()

    def AtualizarReaderStatus(self, RowID, Status):
        cursor = self.Settings.cursor()
        cursor.execute("UPDATE Readers SET Status = ? WHERE rowid = ?", (Status, RowID))
        self.Settings.commit()
